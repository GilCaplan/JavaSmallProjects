package com.example.radiobuttons;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

    public class MainActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener, RadioGroup.OnCheckedChangeListener {

        private ImageView Hacked;
        private TextView textView;
        private ProgressBar progressBar;
        private RadioGroup radioGroup;
        private SeekBar seekBar;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            Hacked = findViewById(R.id.hacked);
            textView = findViewById(R.id.text);
            progressBar = findViewById(R.id.prog);
            seekBar = findViewById(R.id.seek);
            radioGroup = findViewById(R.id.rg);
            radioGroup.setOnCheckedChangeListener(this);
            seekBar.setOnSeekBarChangeListener(this);
        }

        @Override
        public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
            progressBar.setProgress(i);
            textView.setText("" + i + "%");
            Hacked.setImageAlpha((int) (i / 100.0 * 255));
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }


        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int i) {
            switch (i) {
                case R.id.r1:
                    Hacked.setImageResource(R.drawable.ddos);
                    break;
                case R.id.r2:
                    Hacked.setImageResource(R.drawable.sys);
                    break;
                case R.id.r3:
                    Hacked.setImageResource(R.drawable.hackedd);
                    break;
                case R.id.r4:
                    Hacked.setImageResource(R.drawable.mim);
                    break;
            }
        }

    }