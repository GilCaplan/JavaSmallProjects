package com.arar.btnfactory;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText editText;
    private LinearLayout con;
    private CheckBox checkBox;
    private TextView stars;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText= findViewById(R.id.editText);
        checkBox =findViewById(R.id.checkBox);
        stars = findViewById(R.id.stars);
        con = new LinearLayout(this);



        con.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) checkBox.getLayoutParams();

        ConstraintLayout constraintLayout = findViewById(R.id.mainLayout);
        ConstraintLayout.LayoutParams newParams = new ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.WRAP_CONTENT,
                ConstraintLayout.LayoutParams.WRAP_CONTENT);

        newParams.leftToLeft = params.leftToLeft;
        newParams.topToTop = checkBox.getId();
        newParams.bottomToBottom= constraintLayout.getId();
        newParams.rightToRight = params.rightToRight;

        constraintLayout.addView(con,newParams);

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    checkBox.setText("HORIZONTAL");
                    con.setOrientation(LinearLayout.HORIZONTAL);
                }else{
                    checkBox.setText("VERTICAL");
                    con.setOrientation(LinearLayout.VERTICAL);
                }

            }
        });

    }

    public void generate(View view) {

        int amount =Integer.parseInt(editText.getText()+"");


        con.setOrientation(LinearLayout.VERTICAL);
        Button[] buttons = new Button[amount];

        for(int i =0;i<amount;i++){
            final int a= i;
            Button currenButton = buttons[i];
            currenButton = new Button(this);
            currenButton.setText(i+"");
            currenButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String s="";
                    for(int j=0;j<a;j++) s+="*";
                    stars.setText(s);
                }
            });
            con.addView(currenButton);
        }
    }
}
